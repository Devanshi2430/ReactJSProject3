
import './App.css';
import LifeCycle from './Components/LifeCycle'
function App() {
  return (
    <>
    <h1>God Is Great.</h1>
    <LifeCycle/>
    </>
  );
}

export default App;

import './App.css';
import FirstRef from './Components/FirstRef_WithoutUsingHook';
// import SecondRef from './Components/SecondRef_WithCallback';
// import RefAndState from './Components/RefAndState';
// import ThirdRef from './Components/ThirdRef_WithcreateRefAnduseRef';
// import StopwatchDemo from './Components/StopWatchExample'
// import ParentFunctionComp from './Components/RefsWithEventBinding_Parent'
// import MUI_With_Ref from './Components/MUI_With_Ref'

function App() {
  return (
     <FirstRef/>
    // <SecondRef/>
    // <RefAndState/>
    // <ThirdRef/>
    // <StopwatchDemo/>
    // <ParentFunctionComp/>
    //<MUI_With_Ref/>
  );
}

export default App;
